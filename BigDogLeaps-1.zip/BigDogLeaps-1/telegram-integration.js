
// وظائف مساعدة للتكامل مع Telegram
class TelegramIntegration {
    constructor(botToken) {
        this.botToken = botToken;
        this.apiUrl = `https://api.telegram.org/bot${botToken}`;
    }

    // إرسال رسالة إلى المستخدم
    async sendMessage(chatId, text, options = {}) {
        const response = await fetch(`${this.apiUrl}/sendMessage`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                chat_id: chatId,
                text: text,
                parse_mode: 'HTML',
                ...options
            })
        });
        return response.json();
    }

    // حفظ نتائج اللعبة
    async saveGameResult(gameData) {
        // يمكنك استخدام قاعدة بيانات بسيطة أو API خارجي هنا
        console.log('Game result saved:', gameData);
        
        // إرسال رسالة للمستخدم بالنتيجة
        if (gameData.user_id) {
            const message = `🎮 <b>نتيجة اللعبة</b>
الفائز: ${gameData.winner}
القطع المتبقية: ${gameData.red_pieces_remaining} أحمر، ${gameData.blue_pieces_remaining} أزرق
وضع اللعبة: ${gameData.game_mode === 'vs-ai' ? 'ضد الكمبيوتر' : 'محلي'}
التوقيت: ${new Date(gameData.timestamp).toLocaleString('ar')}`;

            await this.sendMessage(gameData.user_id, message);
        }
    }

    // إرسال إحصائيات اللاعب
    async sendPlayerStats(chatId, stats) {
        const message = `📊 <b>إحصائياتك</b>
🏆 الانتصارات: ${stats.wins}
❌ الهزائم: ${stats.losses}
🎯 معدل الفوز: ${((stats.wins / (stats.wins + stats.losses)) * 100).toFixed(1)}%
🎮 إجمالي الألعاب: ${stats.wins + stats.losses}`;

        await this.sendMessage(chatId, message);
    }

    // إنشاء لوحة مفاتيح للعبة
    createGameKeyboard() {
        return {
            inline_keyboard: [
                [
                    {
                        text: "🎮 العب الآن",
                        web_app: { url: "YOUR_REPLIT_URL" }
                    }
                ],
                [
                    {
                        text: "📊 الإحصائيات",
                        callback_data: "stats"
                    },
                    {
                        text: "🏆 أفضل النتائج",
                        callback_data: "leaderboard"
                    }
                ],
                [
                    {
                        text: "📱 مشاركة اللعبة",
                        switch_inline_query: "تعال نلعب لعبة القفز الممتعة! 🎮"
                    }
                ]
            ]
        };
    }
}

// مثال على استخدام التكامل
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TelegramIntegration;
}
