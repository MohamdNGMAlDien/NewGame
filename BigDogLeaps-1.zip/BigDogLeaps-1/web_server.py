
from http.server import HTTPServer, SimpleHTTPRequestHandler
import os
import threading

class GameHTTPRequestHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

def start_web_server():
    """تشغيل web server لعرض اللعبة"""
    port = 5000
    server_address = ('0.0.0.0', port)
    
    # تغيير مجلد العمل لموقع الملفات
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    httpd = HTTPServer(server_address, GameHTTPRequestHandler)
    print(f"🌐 Web server يعمل على البورت {port}")
    print(f"🎮 اللعبة متاحة على: https://{os.environ.get('REPL_SLUG', 'your-repl')}.{os.environ.get('REPL_OWNER', 'your-username')}.repl.co")
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("🛑 تم إيقاف Web server")
        httpd.shutdown()

if __name__ == "__main__":
    start_web_server()
