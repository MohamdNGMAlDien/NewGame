
import threading
import time
import subprocess
import sys

def run_telegram_bot():
    """تشغيل البوت"""
    try:
        subprocess.run([sys.executable, "telegram_bot.py"])
    except Exception as e:
        print(f"خطأ في تشغيل البوت: {e}")

def run_web_server():
    """تشغيل web server"""
    try:
        subprocess.run([sys.executable, "web_server.py"])
    except Exception as e:
        print(f"خطأ في تشغيل web server: {e}")

if __name__ == "__main__":
    print("🚀 بدء تشغيل البوت و Web Server...")
    
    # تشغيل web server في thread منفصل
    web_thread = threading.Thread(target=run_web_server, daemon=True)
    web_thread.start()
    
    # انتظار قليل للتأكد من بدء web server
    time.sleep(2)
    
    # تشغيل البوت في thread منفصل
    bot_thread = threading.Thread(target=run_telegram_bot, daemon=True)
    bot_thread.start()
    
    print("✅ البوت و Web Server جاهزان!")
    
    try:
        # إبقاء البرنامج الرئيسي يعمل
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("🛑 تم إيقاف الخدمات")
