
# لعبة القفز - Telegram Web App

لعبة استراتيجية ممتعة للعب على Telegram مع دعم كامل لـ Telegram Web Apps API.

## المميزات

- 🎮 لعبة استراتيجية مثيرة على لوح 5x5
- 🤖 وضع اللعب ضد الكمبيوتر
- 👥 وضع اللعب المحلي
- 📱 تكامل كامل مع Telegram Web Apps
- 🎯 تأثيرات بصرية وصوتية
- 📊 حفظ النتائج والإحصائيات
- 🏆 مشاركة النتائج

## إعداد البوت في Telegram

### 1. إنشاء بوت جديد

1. ابحث عن @BotFather في Telegram
2. أرسل `/newbot`
3. اختر اسم للبوت
4. احفظ الـ Token

### 2. إعداد Web App

1. أرسل `/newapp` لـ BotFather
2. اختر البوت الذي أنشأته
3. أرسل اسم التطبيق
4. أرسل وصف مختصر
5. أرسل رابط Replit الخاص بك: `https://YOUR-REPL-NAME.YOUR-USERNAME.repl.co`
6. ارفع صورة للتطبيق (اختياري)

### 3. إعداد أوامر البوت

أرسل `/setcommands` لـ BotFather واكتب:

```
start - بدء اللعبة
play - العب الآن
stats - عرض الإحصائيات
help - المساعدة
```

### 4. ربط البوت مع كود Python/Node.js

```python
import telebot
from telebot.types import WebAppInfo, InlineKeyboardMarkup, InlineKeyboardButton

bot = telebot.TeleBot("YOUR_BOT_TOKEN")

@bot.message_handler(commands=['start', 'play'])
def start_game(message):
    web_app = WebAppInfo("https://YOUR-REPL-NAME.YOUR-USERNAME.repl.co")
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("🎮 العب الآن", web_app=web_app))
    
    bot.send_message(
        message.chat.id,
        "🎮 مرحباً بك في لعبة القفز!\n\nلعبة استراتيجية مثيرة على لوح 5x5. اضغط على الزر أدناه للبدء:",
        reply_markup=keyboard
    )

bot.infinity_polling()
```

## استخدام اللعبة

1. افتح البوت في Telegram
2. أرسل `/start`
3. اضغط على "العب الآن"
4. استمتع باللعبة!

## المميزات التقنية

- دعم كامل لـ Telegram Web Apps API
- Haptic Feedback للأجهزة المدعومة
- تكامل مع ثيم Telegram
- حفظ النتائج والإحصائيات
- مشاركة النتائج مع الأصدقاء
- تحسين للأجهزة المحمولة

## التطوير

اللعبة مبنية بـ:
- HTML5 Canvas للرسم
- JavaScript للمنطق
- CSS3 للتصميم
- Telegram Web Apps API للتكامل

## الدعم

إذا واجهت أي مشاكل، تأكد من:
- تحديث Telegram لآخر إصدار
- التأكد من صحة رابط Web App
- مراجعة console.log للأخطاء
