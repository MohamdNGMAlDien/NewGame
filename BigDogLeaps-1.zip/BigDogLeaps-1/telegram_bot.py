import telebot
import json
import threading
import time
import os
from telebot.types import WebAppInfo, InlineKeyboardMarkup, InlineKeyboardButton, BotCommand

# توكن البوت
BOT_TOKEN = "8062473069:AAHfCRUmd4A1No3QhBGdU29kCtKBxwopeMI"

# الحصول على URL الصحيح بشكل ديناميكي
def get_game_url():
    # جرب URLs مختلفة
    possible_urls = [
        f"https://{os.environ.get('REPL_SLUG', 'workspace')}.{os.environ.get('REPL_OWNER', 'dadm1407')}.repl.co",
        f"https://{os.environ.get('REPL_SLUG', 'workspace')}-{os.environ.get('REPL_OWNER', 'dadm1407')}.replit.dev",
        "https://workspace.dadm1407.repl.co"
    ]
    return possible_urls[0]

GAME_URL = get_game_url()

# إنشاء البوت
bot = telebot.TeleBot(BOT_TOKEN)

# قاموس لحفظ بيانات اللاعبين
players_data = {}

def save_player_data():
    """حفظ بيانات اللاعبين في ملف"""
    try:
        with open('players_data.json', 'w', encoding='utf-8') as f:
            json.dump(players_data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"خطأ في حفظ البيانات: {e}")

def load_player_data():
    """تحميل بيانات اللاعبين من الملف"""
    global players_data
    try:
        with open('players_data.json', 'r', encoding='utf-8') as f:
            players_data = json.load(f)
    except FileNotFoundError:
        players_data = {}
    except Exception as e:
        print(f"خطأ في تحميل البيانات: {e}")
        players_data = {}

def get_player_stats(user_id):
    """الحصول على إحصائيات اللاعب"""
    if str(user_id) not in players_data:
        players_data[str(user_id)] = {
            'wins': 0,
            'losses': 0,
            'games_played': 0,
            'last_played': None
        }
    return players_data[str(user_id)]

def update_player_stats(user_id, won=False):
    """تحديث إحصائيات اللاعب"""
    stats = get_player_stats(user_id)
    stats['games_played'] += 1
    if won:
        stats['wins'] += 1
    else:
        stats['losses'] += 1
    stats['last_played'] = time.time()
    save_player_data()

@bot.message_handler(commands=['start'])
def start_message(message):
    """رسالة البداية"""
    user_name = message.from_user.first_name

    # تجربة URL مختلف في كل مرة
    current_url = GAME_URL
    print(f"استخدام URL: {current_url}")

    welcome_text = f"""
🎮 مرحباً {user_name}! 

أهلاً بك في لعبة القفز الاستراتيجية!

🔹 لعبة مثيرة على لوح 5×5
🔹 العب ضد الكمبيوتر أو مع صديق
🔹 تأثيرات بصرية رائعة

اضغط على الزر أدناه لبدء اللعبة:
    """

    # إنشاء لوحة المفاتيح مع URL محدث
    web_app = WebAppInfo(current_url)
    keyboard = InlineKeyboardMarkup()
    keyboard.row(InlineKeyboardButton("🎮 العب الآن", web_app=web_app))
    keyboard.row(InlineKeyboardButton("🔗 فتح في المتصفح", url=current_url))
    keyboard.row(InlineKeyboardButton("📱 مشاركة اللعبة", switch_inline_query="تعال نلعب لعبة القفز! 🎮"))

    bot.send_message(message.chat.id, welcome_text, reply_markup=keyboard)

@bot.message_handler(commands=['play'])
def play_game(message):
    """بدء اللعبة مباشرة"""
    current_url = GAME_URL
    web_app = WebAppInfo(current_url)
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("🎮 العب الآن", web_app=web_app))
    keyboard.add(InlineKeyboardButton("🔗 فتح في المتصفح", url=current_url))

    bot.send_message(
        message.chat.id,
        f"🎮 اللعبة جاهزة!\n\nURL: {current_url}\n\naضغط على أحد الأزرار:",
        reply_markup=keyboard
    )

@bot.message_handler(commands=['stats'])
def show_stats(message):
    """عرض الإحصائيات"""
    user_id = message.from_user.id
    stats = get_player_stats(user_id)
    
    total_games = stats['games_played']
    wins = stats['wins']
    losses = stats['losses']
    win_rate = (wins / total_games * 100) if total_games > 0 else 0
    
    stats_text = f"""
📊 <b>إحصائياتك في لعبة القفز</b>

🏆 الانتصارات: {wins}
❌ الهزائم: {losses}
🎮 إجمالي الألعاب: {total_games}
📈 معدل الفوز: {win_rate:.1f}%

{f"🕒 آخر لعبة: {time.strftime('%Y-%m-%d %H:%M', time.localtime(stats['last_played']))}" if stats['last_played'] else ""}
    """
    
    keyboard = InlineKeyboardMarkup()
    web_app = WebAppInfo(GAME_URL)
    keyboard.add(InlineKeyboardButton("🎮 العب مرة أخرى", web_app=web_app))
    
    bot.send_message(message.chat.id, stats_text, parse_mode='HTML', reply_markup=keyboard)

@bot.message_handler(commands=['test'])
def test_game(message):
    """أمر اختبار للتأكد من عمل الروابط"""
    current_url = GAME_URL
    test_text = f"""
🔧 اختبار الاتصال:

URL الحالي: {current_url}
البوت: يعمل ✅
Web App: جرب الأزرار أدناه

إذا لم تعمل اللعبة، جرب فتحها في المتصفح مباشرة.
    """

    keyboard = InlineKeyboardMarkup()
    keyboard.row(InlineKeyboardButton("🎮 Web App", web_app=WebAppInfo(current_url)))
    keyboard.row(InlineKeyboardButton("🌐 المتصفح", url=current_url))

    bot.send_message(message.chat.id, test_text, reply_markup=keyboard)

@bot.message_handler(commands=['help'])
def help_message(message):
    """رسالة المساعدة"""
    help_text = """
📖 مساعدة لعبة القفز:

🎯 الهدف: أزل جميع قطع الخصم

🎮 طريقة اللعب:
• اضغط على قطعتك لتحديدها
• اضغط على المربع المجاور للانتقال
• اقفز فوق قطع الخصم لإزالتها

الأوامر المتاحة:
/start - البداية
/play - العب الآن  
/test - اختبار الاتصال
/help - المساعدة

إذا لم تعمل اللعبة، جرب أمر /test
    """
    
    keyboard = InlineKeyboardMarkup()
    web_app = WebAppInfo(GAME_URL)
    keyboard.add(InlineKeyboardButton("🎮 العب الآن", web_app=WebAppInfo(GAME_URL)))

    bot.send_message(message.chat.id, help_text, reply_markup=keyboard)

@bot.callback_query_handler(func=lambda call: True)
def handle_callback(call):
    """معالجة ضغطات الأزرار"""
    if call.data == "stats":
        show_stats(call.message)
    elif call.data == "help":
        help_message(call.message)
    
    bot.answer_callback_query(call.id)

@bot.message_handler(content_types=['web_app_data'])
def handle_web_app_data(message):
    """معالجة البيانات الواردة من Web App"""
    try:
        data = json.loads(message.web_app_data.data)
        user_name = message.from_user.first_name

        result_text = f"""
🎉 انتهت اللعبة!

الفائز: {data.get('winner', 'غير محدد')}
تهانينا {user_name}! 🎊
        """

        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton("🎮 العب مرة أخرى", web_app=WebAppInfo(GAME_URL)))

        bot.send_message(message.chat.id, result_text, reply_markup=keyboard)

    except Exception as e:
        print(f"خطأ في معالجة بيانات Web App: {e}")
        bot.send_message(message.chat.id, "تم استلام النتيجة! 🎮")

@bot.inline_handler(lambda query: True)
def handle_inline_query(query):
    """معالجة الاستعلامات المضمنة لمشاركة اللعبة"""
    results = []
    
    article = telebot.types.InlineQueryResultArticle(
        id='1',
        title='لعبة القفز 🎮',
        description='لعبة استراتيجية ممتعة على لوح 5×5',
        input_message_content=telebot.types.InputTextMessageContent(
            message_text=f"""
🎮 <b>لعبة القفز - تحدي استراتيجي!</b>

🔹 لعبة مثيرة على لوح 5×5
🔹 العب ضد الكمبيوتر أو مع الأصدقاء
🔹 تأثيرات بصرية رائعة

انضم للعبة الآن! 👇
            """,
            parse_mode='HTML'
        ),
        reply_markup=InlineKeyboardMarkup().add(
            InlineKeyboardButton("🎮 العب الآن", web_app=WebAppInfo(GAME_URL))
        )
    )
    
    results.append(article)
    bot.answer_inline_query(query.id, results, cache_time=1)

def setup_bot_commands():
    """إعداد أوامر البوت"""
    commands = [
        BotCommand("start", "بدء اللعبة"),
        BotCommand("play", "العب الآن"),
        BotCommand("test", "اختبار الاتصال"),
        BotCommand("help", "المساعدة")
    ]
    bot.set_my_commands(commands)

def keep_alive():
    """إبقاء البوت نشطاً"""
    while True:
        try:
            time.sleep(300)  # انتظار 5 دقائق
            print("البوت ما زال نشطاً...")
        except:
            break

if __name__ == "__main__":
    print("🚀 بدء تشغيل بوت لعبة القفز...")
    print(f"🌐 رابط اللعبة: {GAME_URL}")

    # تحميل بيانات اللاعبين
    load_player_data()
    
    # إعداد أوامر البوت
    setup_bot_commands()
    
    # بدء thread للحفاظ على نشاط البوت
    threading.Thread(target=keep_alive, daemon=True).start()
    
    print("✅ البوت جاهز للعمل!")
    
    # تشغيل البوت
    try:
        bot.infinity_polling(none_stop=True, timeout=60)
    except Exception as e:
        print(f"خطأ في تشغيل البوت: {e}")
        time.sleep(5)